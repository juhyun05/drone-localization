"""Extract palette-colored building masks and contours from uint8 camera images."""

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class ColorConfig:
    hue_tolerance: int = 7  # OpenCV hue units, where 180 wraps to 0
    saturation_tolerance: int = 55
    value_tolerance: int = 95
    morph_size: int = 3
    min_area_px: int = 12


@dataclass
class BuildingObservation:
    labels: np.ndarray
    contours: dict[int, list[np.ndarray]]


class BuildingDetector:
    def __init__(self, palette: tuple, config: ColorConfig = ColorConfig()):
        if not 1 <= len(palette) <= 255:
            raise ValueError("expected 1 to 255 building colors")
        if not (1 <= config.morph_size and config.morph_size % 2 and config.min_area_px >= 1):
            raise ValueError("morph_size must be positive and odd; min_area_px must be positive")
        if not (0 <= config.hue_tolerance <= 90 and 0 <= config.saturation_tolerance <= 255
                and 0 <= config.value_tolerance <= 255):
            raise ValueError("HSV tolerances must fit their OpenCV channel ranges")
        self.config = config
        hsv = cv2.cvtColor(np.asarray([palette], np.uint8), cv2.COLOR_BGR2HSV)[0].astype(int)
        difference = np.abs(np.arange(180)[:, None] - hsv[:, 0])
        circular = np.minimum(difference, 180 - difference)
        nearest = np.argmin(circular, axis=1)
        self.hue_distance = circular[np.arange(180), nearest]
        self.color_for_hue = hsv[nearest]
        self.label_for_hue = (nearest + 1).astype(np.uint8)
        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,
                                               (config.morph_size, config.morph_size))

    def detect(self, frame: np.ndarray, *, rgb: bool = False,
               include_contours: bool = True) -> BuildingObservation:
        """Return cleaned color labels and outer contours in input-image pixels."""
        if frame.dtype != np.uint8 or frame.ndim != 3 or frame.shape[2] != 3:
            raise ValueError("expected a uint8 BGR or RGB image with three channels")
        config = self.config
        hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV if rgb else cv2.COLOR_BGR2HSV)
        hue, sat, val = hsv.transpose(2, 0, 1)
        expected = self.color_for_hue[hue]
        valid = ((self.hue_distance[hue] <= config.hue_tolerance)
                 & (np.abs(sat - expected[..., 1]) <= config.saturation_tolerance)
                 & (np.abs(val - expected[..., 2]) <= config.value_tolerance))
        raw = np.where(valid, self.label_for_hue[hue], 0)
        labels = np.zeros_like(raw)
        contours = {}
        for label in np.unique(raw[valid]):
            mask = (raw == label).astype(np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, self.kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, self.kernel)
            count, components, stats, _ = cv2.connectedComponentsWithStats(mask)
            keep = stats[:, cv2.CC_STAT_AREA] >= config.min_area_px
            keep[0] = False
            if count == 1 or not keep.any():
                continue
            cleaned = keep[components]
            # Prefer the original observed color when closed masks touch.
            labels[cleaned & ((labels == 0) | (raw == label))] = label
            if include_contours:
                outlines, _ = cv2.findContours(cleaned.astype(np.uint8), cv2.RETR_EXTERNAL,
                                                cv2.CHAIN_APPROX_SIMPLE)
                contours[int(label)] = outlines
        return BuildingObservation(labels, contours)
