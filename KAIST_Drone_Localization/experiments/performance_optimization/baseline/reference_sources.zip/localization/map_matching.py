"""Search translation, yaw, and a configurable range of camera ground spans."""

from dataclasses import dataclass, field, replace
import math
from functools import lru_cache
from time import perf_counter

import cv2
import numpy as np

from .camera_simulator import CameraConfig, image_center
from .image_processing import BuildingDetector, ColorConfig
from .map_loader import CampusMap, MapRaster


SPAN_SEPARATION_RATIO = 1.35


def angle_error(a_deg: float, b_deg: float) -> float:
    """Return the smallest unsigned angle between two headings, in degrees."""
    return abs((a_deg - b_deg + 180) % 360 - 180)


@dataclass(frozen=True)
class SearchConfig:
    pixels_per_m: float = 80.0
    nominal_span_m: float = CameraConfig().footprint_m
    scale_factors: tuple[float, ...] = (0.8, 0.9, 1.0, 1.1, 1.2)
    yaw_step_deg: float = 5.0
    local_radius_m: float = 0.25
    min_frame_fraction: float = 0.0125
    min_foreground: int = 35  # Pixels at matching resolution
    min_score: float = 0.36
    min_margin: float = 0.07
    separation_m: float = 0.08
    separation_deg: float = 20.0
    auto_scale: bool = False
    scale_min: float = 0.5
    scale_max: float = 2.0
    scale_steps: int = 15
    scale_refine_steps: int = 5
    min_effective_fraction: float = 0.35

    def __post_init__(self):
        positive = (self.pixels_per_m, self.nominal_span_m, self.yaw_step_deg,
                    self.local_radius_m, self.min_foreground, self.separation_m,
                    self.separation_deg, *self.scale_factors)
        if not self.scale_factors or not all(math.isfinite(x) and x > 0 for x in positive):
            raise ValueError("search scale, resolution, step, and radii must be positive")
        fractions = (self.min_frame_fraction, self.min_score, self.min_margin, self.min_effective_fraction)
        if self.yaw_step_deg > 180 or not all(0 <= value <= 1 for value in fractions):
            raise ValueError("invalid yaw step, coverage, score threshold, or margin")
        if not (0 < self.scale_min < self.scale_max < math.inf
                and 0 < self.nominal_span_m * self.scale_min < self.nominal_span_m * self.scale_max < math.inf
                and all(type(steps) is int and steps >= 3
                        for steps in (self.scale_steps, self.scale_refine_steps))):
            raise ValueError("automatic scale requires 0 < min < max and at least three steps per stage")


@dataclass(frozen=True)
class Estimate:
    success: bool
    reason: str
    score: float = 0.0
    margin: float = 0.0
    x_m: float | None = None
    y_m: float | None = None
    yaw_deg: float | None = None
    span_m: float | None = None


@dataclass(frozen=True)
class MatchCandidate:
    score: float
    x_m: float
    y_m: float
    yaw_deg: float
    span_m: float


@dataclass
class MatchDiagnostics:
    """Optional search evidence in map units, including rejected hypotheses."""

    coarse_by_span: dict[float, MatchCandidate] = field(default_factory=dict)
    verified_by_span: dict[float, MatchCandidate] = field(default_factory=dict)
    candidates: tuple[MatchCandidate, ...] = ()
    runner_up: MatchCandidate | None = None


@dataclass(frozen=True)
class _ScoreGrid:
    yaw_deg: float
    span_m: float
    bounds: tuple[int, int, int, int]
    scores: np.ndarray

    def peak(self):
        _, score, _, (col, row) = cv2.minMaxLoc(self.scores)
        return score, col + self.bounds[0], row + self.bounds[1], self.yaw_deg, self.span_m


@dataclass(frozen=True)
class _Observation:
    labels: np.ndarray
    confidence: np.ndarray | None


class MapMatcher:
    def __init__(self, campus: CampusMap, search: SearchConfig = SearchConfig(),
                 colors: ColorConfig = ColorConfig()):
        self.raster = MapRaster(campus, search.pixels_per_m)
        self.labels = self.raster.labels()
        self.detector = BuildingDetector(campus.palette, colors)
        self.search = search
        self.coarse = (MapMatcher(campus, replace(search, auto_scale=False,
                                                 pixels_per_m=search.pixels_per_m / 2), colors)
                       if search.auto_scale else None)

    def project_labels(self, frame_shape, candidate):
        """Project map labels into camera pixels for a verified or diagnostic candidate."""
        height, width = frame_shape[:2]
        center = image_center(width, height)
        scale = candidate.span_m * self.raster.pixels_per_m / width
        transform = cv2.getRotationMatrix2D(center, candidate.yaw_deg, scale)
        transform[:, 2] += self.raster.xy_to_uv((candidate.x_m, candidate.y_m)) - center
        return cv2.warpAffine(self.labels, transform, (width, height),
                              flags=cv2.INTER_NEAREST | cv2.WARP_INVERSE_MAP)

    def estimate(self, frame: np.ndarray, prior_xy: tuple[float, float] | None = None, *,
                 radius_m: float | None = None, prior_yaw: float | None = None,
                 yaw_radius_deg: float = 30, prior_span_m: float | None = None,
                 diagnostics: MatchDiagnostics | None = None,
                 confidence_mask: np.ndarray | None = None,
                 timings: dict[str, float] | None = None) -> Estimate:
        """Estimate from BGR pixels, optionally narrowing xy, yaw and span around priors."""
        if timings is not None:
            segmentation_start = perf_counter()
        labels = self.detector.detect(frame, include_contours=False).labels
        if timings is not None:
            timings["hsv_ms"] = (perf_counter() - segmentation_start) * 1000
        config = self.search
        if diagnostics is not None:
            diagnostics.coarse_by_span.clear()
            diagnostics.verified_by_span.clear()
            diagnostics.candidates = ()
            diagnostics.runner_up = None
        confidence = None if confidence_mask is None else np.asarray(confidence_mask, dtype=np.float32)
        if confidence is not None:
            if (confidence.shape != labels.shape or not np.isfinite(confidence).all()
                    or confidence.min() < 0 or confidence.max() > 1):
                raise ValueError("confidence_mask must match the image and contain finite weights in [0, 1]")
            if confidence.min() == 1:
                confidence = None
        if np.count_nonzero(labels) < max(1, config.min_frame_fraction * labels.size):
            return Estimate(False, "insufficient visible buildings")
        if confidence is not None and not self._reliable_observation(labels, confidence):
            return Estimate(False, "insufficient reliable observations")
        observation = _Observation(labels, confidence)
        radius_m = config.local_radius_m if radius_m is None else radius_m
        bounds = self._search_bounds(prior_xy, radius_m)
        if bounds is None:
            return Estimate(False, "search area outside map")
        if config.auto_scale:
            grids = self._automatic_grids(observation, bounds, prior_xy, radius_m, prior_yaw,
                                          yaw_radius_deg, prior_span_m, diagnostics)
            result = self._decide(grids, diagnostics)
            if result.success and prior_xy is not None and prior_span_m is not None:
                lower = min(grid.span_m for grid in grids)
                upper = max(grid.span_m for grid in grids)
                # An edge maximum inside the allowed band can be the flank of a better
                # wider or narrower fit. Let the tracker retry without the width prior.
                at_lower_limit = (result.span_m == lower
                                  and lower > config.nominal_span_m * config.scale_min)
                at_upper_limit = (result.span_m == upper
                                  and upper < config.nominal_span_m * config.scale_max)
                if at_lower_limit or at_upper_limit:
                    return Estimate(False, "span reaches local search limit", result.score, result.margin)
            return result

        spans = [config.nominal_span_m * factor for factor in config.scale_factors]
        if prior_span_m is not None:
            spans.sort()
            closest = min(range(len(spans)), key=lambda i: abs(spans[i] - prior_span_m))
            spans = spans[max(0, closest - 1):closest + 2]
        headings = _headings(config.yaw_step_deg, prior_yaw, yaw_radius_deg)
        grids = self._score_grids(observation, spans, headings, bounds, prior_xy, radius_m)
        return self._decide(grids, diagnostics)

    def _reliable_observation(self, labels, confidence):
        effective = float(confidence.mean())
        if effective < self.search.min_effective_fraction:
            return False
        mass = np.bincount(labels.ravel(), weights=confidence.ravel(), minlength=1)[1:]
        if mass.sum() < max(1, self.search.min_frame_fraction * labels.size):
            return False
        # With little usable area, a lone weak color is especially easy to match by chance.
        return effective >= 0.55 or np.count_nonzero(mass >= labels.size * 0.0025) >= 2

    def _score_grids(self, observation, spans, headings, bounds, prior_xy, radius_m, *, min_foreground=None):
        """Correlate the same color IoU templates at either map resolution."""
        config = self.search
        labels, confidence = observation.labels, observation.confidence
        height, width = labels.shape
        min_foreground = config.min_foreground if min_foreground is None else min_foreground
        x0, y0, x1, y1 = bounds
        radius = math.ceil(math.hypot(width, height) / width / 2
                           * config.pixels_per_m * max(spans)) + 1
        padded, padded_foreground = self._padded_map(radius)
        area = padded[y0:y1 + 2 * radius, x0:x1 + 2 * radius]
        foreground = padded_foreground[y0:y1 + 2 * radius, x0:x1 + 2 * radius]
        layers = {}
        for label in np.unique(labels):
            if label:
                mask = (area == label).astype(np.uint8)
                layers[label] = (mask if confidence is None else mask.astype(np.float32),
                                 cv2.boundingRect(mask))
        outside = None
        if prior_xy is not None:
            u, v = self.raster.xy_to_uv(prior_xy)
            dx = np.arange(x0, x1) - u
            dy = np.arange(y0, y1) - v
            outside = dy[:, None] ** 2 + dx ** 2 > (radius_m * config.pixels_per_m) ** 2

        for span in spans:
            scale = span * config.pixels_per_m / width
            for yaw in headings:
                transform, size, footprint = _template_geometry(width, height, radius, float(yaw), scale)
                rotated = cv2.warpAffine(labels, transform, size, flags=cv2.INTER_NEAREST)
                weights = (None if confidence is None else
                           cv2.warpAffine(confidence, transform, size, flags=cv2.INTER_NEAREST))
                count = np.count_nonzero(rotated) if weights is None else weights[rotated > 0].sum()
                if count < min_foreground:
                    continue
                scores = _color_iou(foreground, layers, rotated, footprint, count, weights=weights)
                if outside is not None:
                    scores[outside] = -1
                yield _ScoreGrid(float(yaw), float(span), bounds, scores)

    def _automatic_grids(self, observation, bounds, prior_xy, radius_m, prior_yaw, yaw_radius, prior_span,
                         diagnostics):
        config = self.search
        minimum, maximum = (config.nominal_span_m * factor
                            for factor in (config.scale_min, config.scale_max))
        if prior_xy is not None and prior_span is not None:
            # A tracking observation usually needs only a small change from the last accepted width.
            spans = np.unique(np.clip(prior_span * np.array([0.92, 1, 1.08]), minimum, maximum))
            headings = _headings(config.yaw_step_deg, prior_yaw, yaw_radius)
            grids = list(self._score_grids(observation, spans, headings, bounds, prior_xy, radius_m))
            if not grids:
                return grids
            best = max((grid.peak() for grid in grids), key=lambda peak: peak[0])
            if best[0] > 0:
                grids.extend(self._refine(observation, self._candidate(best), bounds, prior_xy, radius_m,
                                          minimum, maximum, math.log(1.08) / 2,
                                          config.yaw_step_deg / 2, 0.05, 3,
                                          prior_yaw=prior_yaw, yaw_radius=yaw_radius))
            return grids

        spans = np.geomspace(minimum, maximum, config.scale_steps)
        yaw_step = min(30, config.yaw_step_deg * 2)
        headings = _headings(yaw_step, prior_yaw, yaw_radius)
        seeds = self._coarse_candidates(observation, spans, headings, prior_xy, radius_m, diagnostics)
        log_step = math.log(config.scale_max / config.scale_min) / (config.scale_steps - 1)
        # Preserve separate locations, headings and distinctly sized hypotheses before refinement.
        seeds = _distinct(seeds, 6, config.separation_m, config.separation_deg,
                          min(math.log(SPAN_SEPARATION_RATIO), max(0.18, 2 * log_step)))
        coarse_pixel_m = 1 / self.coarse.search.pixels_per_m
        # Cover the separation boundary even when the two centers round to nearby coarse pixels.
        refine_radius = max(3 * coarse_pixel_m, config.separation_m + coarse_pixel_m)
        grids = []
        for seed in seeds:
            grids.extend(self._refine(observation, seed, bounds, prior_xy, radius_m, minimum, maximum,
                                      log_step / 2, yaw_step / 2, refine_radius,
                                      config.scale_refine_steps, prior_yaw=prior_yaw,
                                      yaw_radius=yaw_radius))
        return grids

    def _coarse_candidates(self, observation, spans, headings, prior_xy, radius_m, diagnostics):
        coarse = self.coarse
        bounds = coarse._search_bounds(prior_xy, radius_m)
        if bounds is None:
            return []
        distance = math.ceil(self.search.separation_m * coarse.search.pixels_per_m) - 1
        candidates = []
        for grid in coarse._score_grids(observation, spans, headings, bounds, prior_xy, radius_m,
                                        min_foreground=max(3, math.ceil(self.search.min_foreground / 4))):
            best = coarse._candidate(grid.peak())
            if diagnostics is not None:
                _record_peak(diagnostics.coarse_by_span, best)
            if best.score <= 0:
                continue
            candidates.append(best)
            # One rotation and width can score well at more than one building cluster.
            remaining = grid.scores.copy()
            col, row = coarse.raster.xy_to_uv((best.x_m, best.y_m)).round().astype(int)
            cv2.circle(remaining, (col - bounds[0], row - bounds[1]), distance, -1, thickness=-1)
            runner_up = coarse._candidate(replace(grid, scores=remaining).peak())
            if runner_up.score > 0:
                candidates.append(runner_up)
        return candidates

    def _refine(self, observation, seed, bounds, prior_xy, radius_m, minimum, maximum,
                log_half_width, yaw_half_width, center_radius, steps, *, prior_yaw, yaw_radius):
        region = self._search_bounds((seed.x_m, seed.y_m), center_radius)
        if region is None:
            return
        tight = (max(bounds[0], region[0]), max(bounds[1], region[1]),
                 min(bounds[2], region[2]), min(bounds[3], region[3]))
        if tight[0] >= tight[2] or tight[1] >= tight[3]:
            return
        spans = seed.span_m * np.exp(np.linspace(-log_half_width, log_half_width, steps))
        spans = np.unique(np.clip(np.append(spans, seed.span_m), minimum, maximum))
        headings = (seed.yaw_deg + np.linspace(-yaw_half_width, yaw_half_width, steps)) % 360
        if prior_yaw is not None:
            window = max(self.search.yaw_step_deg / 2, yaw_radius)
            offsets = (headings - prior_yaw + 180) % 360 - 180
            headings = np.unique((prior_yaw + np.clip(offsets, -window, window)) % 360)
        yield from self._score_grids(observation, spans, headings, tight, prior_xy, radius_m)

    def _candidate(self, peak):
        score, col, row, yaw, span = peak
        x_m, y_m = self.raster.uv_to_xy((col, row))
        return MatchCandidate(score, float(x_m), float(y_m), yaw, span)

    def _decide(self, grids, diagnostics):
        grids = list(grids)
        if not grids:
            return Estimate(False, "insufficient visible buildings")
        peaks = [grid.peak() for grid in grids]
        best = max(peaks, key=lambda peak: peak[0])
        score, col, row, yaw, span = best
        config = self.search
        if diagnostics is not None:
            candidates = [self._candidate(peak) for peak in peaks]
            for candidate in candidates:
                _record_peak(diagnostics.verified_by_span, candidate)
            diagnostics.candidates = tuple(_distinct(candidates, 8, config.separation_m,
                                                      config.separation_deg, math.log(SPAN_SEPARATION_RATIO)))
        if score < config.min_score:
            return Estimate(False, "low match score", max(0.0, score))
        margin = score - self._alternative_score(grids, col, row, yaw, span, diagnostics)
        if margin < config.min_margin:
            return Estimate(False, "ambiguous pose", score, margin)
        winner = self._candidate(best)
        return Estimate(True, "matched", score, margin, winner.x_m, winner.y_m, yaw, span)

    @lru_cache(maxsize=8)
    def _padded_map(self, radius):
        padded = np.pad(self.labels, radius)
        return padded, (padded > 0).astype(np.float32)

    def _search_bounds(self, prior_xy, radius_m):
        """Return half-open UV bounds for candidate camera centers on the map."""
        config = self.search
        width = math.floor(self.raster.campus.width_m * config.pixels_per_m) + 1
        height = math.floor(self.raster.campus.height_m * config.pixels_per_m) + 1
        if prior_xy is None:
            return 0, 0, width, height
        u, v = self.raster.xy_to_uv(prior_xy)
        radius = radius_m * config.pixels_per_m
        x0, y0 = max(0, math.ceil(u - radius)), max(0, math.ceil(v - radius))
        x1, y1 = min(width, math.floor(u + radius) + 1), min(height, math.floor(v + radius) + 1)
        return (x0, y0, x1, y1) if x0 < x1 and y0 < y1 else None

    def _alternative_score(self, grids, col, row, yaw, span, diagnostics):
        """Find the best distinct pose, including substantially different spans in auto mode."""
        config = self.search
        separation_sq = (config.separation_m * config.pixels_per_m) ** 2
        masks = {}
        runner_up = 0.0
        for grid in grids:
            mask = None
            if (angle_error(grid.yaw_deg, yaw) >= config.separation_deg
                    or (config.auto_scale
                        and max(grid.span_m / span, span / grid.span_m) >= SPAN_SEPARATION_RATIO)):
                candidates = grid.scores
            else:
                if grid.bounds not in masks:
                    x0, y0, x1, y1 = grid.bounds
                    v, u = np.ogrid[y0:y1, x0:x1]
                    masks[grid.bounds] = (u - col) ** 2 + (v - row) ** 2 >= separation_sq
                mask = masks[grid.bounds]
                candidates = grid.scores[mask]
            score = float(candidates.max(initial=0))
            if score > runner_up:
                runner_up = score
                if diagnostics is not None:
                    alternative = grid if mask is None else replace(grid, scores=np.where(mask, grid.scores, -1))
                    diagnostics.runner_up = self._candidate(alternative.peak())
        return runner_up


def _headings(step, prior_yaw, window):
    headings = np.arange(0, 360, step)
    if prior_yaw is None:
        return headings
    return [yaw for yaw in headings if angle_error(yaw, prior_yaw) <= max(step / 2, window)]


def _record_peak(by_span, candidate):
    best = by_span.get(candidate.span_m)
    if best is None or candidate.score > best.score:
        by_span[candidate.span_m] = candidate


def _distinct(candidates, limit, distance, angle, log_span):
    kept = []
    for candidate in sorted(candidates, key=lambda item: item.score, reverse=True):
        if any(math.hypot(candidate.x_m - other.x_m, candidate.y_m - other.y_m) < distance
               and angle_error(candidate.yaw_deg, other.yaw_deg) < angle
               and abs(math.log(candidate.span_m / other.span_m)) < log_span for other in kept):
            continue
        kept.append(candidate)
        if len(kept) == limit:
            break
    return kept


@lru_cache(maxsize=512)
def _template_geometry(width, height, radius, yaw, scale):
    center = image_center(width, height)
    transform = cv2.getRotationMatrix2D(center, yaw, scale)
    transform[:, 2] += np.asarray((radius, radius)) - center
    size = (2 * radius + 1,) * 2
    visible = cv2.warpAffine(np.ones((height, width), np.uint8), transform, size,
                             flags=cv2.INTER_NEAREST)
    x, y, w, h = cv2.boundingRect(visible)
    footprint = (x, y, visible[y:y + h, x:x + w].astype(np.float32))
    return transform, size, footprint


def _color_iou(foreground, layers, rotated, footprint, observed_count, *, weights=None):
    """Return color-aware intersection over union for every template center."""
    x, y, visible = footprint
    h, w = visible.shape
    if weights is not None:
        visible = weights[y:y + h, x:x + w]
    fh, fw = foreground.shape
    vh, vw = rotated.shape
    intersection = np.zeros((fh - vh + 1, fw - vw + 1), dtype=np.float32)
    left, top = intersection.shape[1], intersection.shape[0]
    right, bottom = 0, 0
    for label, (map_mask, (mx, my, mw, mh)) in layers.items():
        if not mw:
            continue
        mask = (rotated == label).astype(np.uint8)
        tx, ty, tw, th = cv2.boundingRect(mask)
        if not tw:
            continue
        # Only translations whose map and observed bounding boxes overlap can score.
        x0, y0 = max(0, mx - tx - tw + 1), max(0, my - ty - th + 1)
        x1 = min(intersection.shape[1], mx + mw - tx)
        y1 = min(intersection.shape[0], my + mh - ty)
        if x0 < x1 and y0 < y1:
            region = map_mask[y0 + ty:y1 + ty + th - 1, x0 + tx:x1 + tx + tw - 1]
            template = mask[ty:ty + th, tx:tx + tw]
            if weights is not None:
                template = template * weights[ty:ty + th, tx:tx + tw]
            intersection[y0:y1, x0:x1] += cv2.matchTemplate(region, template, cv2.TM_CCORR)
            left, top = min(left, x0), min(top, y0)
            right, bottom = max(right, x1), max(bottom, y1)
    # Without same-color overlap the score is already zero, regardless of the union.
    result = intersection.astype(np.result_type(intersection, observed_count), copy=False)
    if right == 0:
        return result
    region = foreground[top + y:bottom + y + h - 1, left + x:right + x + w - 1]
    predicted = cv2.matchTemplate(region, visible, cv2.TM_CCORR)
    scores = intersection[top:bottom, left:right]
    # Only the unweighted correlations are integral counts.
    if weights is None:
        predicted, scores = np.rint(predicted), np.rint(scores)
    predicted = np.maximum(predicted, 0)
    overlap = np.clip(scores, 0, np.minimum(predicted, observed_count))
    result[top:bottom, left:right] = overlap / (predicted + observed_count - overlap)
    return result
